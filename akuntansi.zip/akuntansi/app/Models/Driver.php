<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
class Driver extends Model { protected $fillable=['code','name','phone','address','is_active']; protected $casts=['is_active'=>'boolean']; public function receivables(): HasMany { return $this->hasMany(DriverReceivable::class); } }
