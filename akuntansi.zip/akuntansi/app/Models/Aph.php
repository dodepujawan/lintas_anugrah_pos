<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Aph extends Model
{
    protected $table = 'aph';

    protected $fillable = [
        'NOFAKTUR',
        'TGLFAKTUR',
        'TGLJT',
        'SUPPLIER',
        'HUTANG',
        'BAYAR',
        'RETUR',
        'DISCOUNT',
        'SALDO',
        'CABANG',
        'KETERANGAN',
        'STATUS',
        'SOURCE',
        'TGLLUNAS',
        'NOJURNAL',
        'USER',
        'USER_UPDATE',
    ];

    protected $casts = [
        'TGLFAKTUR' => 'date',
        'TGLJT' => 'date',
        'TGLLUNAS' => 'date',
        'HUTANG' => 'decimal:2',
        'BAYAR' => 'decimal:2',
        'RETUR' => 'decimal:2',
        'DISCOUNT' => 'decimal:2',
        'SALDO' => 'decimal:2',
    ];

    public function details(): HasMany
    {
        return $this->hasMany(Bapd::class, 'NOFAKTUR', 'NOFAKTUR');
    }

    public function supplierMaster(): BelongsTo
    {
        return $this->belongsTo(Msupplier::class, 'SUPPLIER', 'SUPPLIER');
    }

    public function getSupplierDisplayAttribute(): string
    {
        return $this->supplierMaster?->display_name ?? $this->SUPPLIER;
    }
}
