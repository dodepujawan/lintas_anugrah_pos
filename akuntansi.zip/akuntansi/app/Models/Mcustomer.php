<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Mcustomer extends Model
{
    protected $table = 'mcustomer';

    protected $fillable = [
        'CUSTOMER',
        'kode_cus',
        'NAMACUST',
        'ALAMAT1',
        'ALAMAT2',
        'KOTA',
        'TELEPON',
        'FAX',
        'EMAIL',
        'KONTAK',
        'NPWP',
        'AREA',
        'SUBAREA',
        'TYPECUST',
        'KOLEKTOR',
        'SETATUS',
        'SALDO',
        'RETURAN',
        'TOPKREDIT',
        'MAXKREDIT',
        'DISC1',
        'DISC2',
        'DISC3',
        'DISC_REG',
        'DISC_CASH',
        'TGL_UPDATE',
        'USERID',
    ];

    protected $casts = [
        'TGL_UPDATE' => 'date',
    ];

    public function getDisplayNameAttribute(): string
    {
        return trim((string) $this->CUSTOMER) . ' - ' . (trim((string) $this->NAMACUST) ?: 'Tanpa Nama');
    }
}
