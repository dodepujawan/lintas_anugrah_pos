<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Arh extends Model
{
    use HasFactory;

    protected $table = 'arh';
    protected $primaryKey = 'id';
    public $incrementing = true;

    protected $fillable = [
        'NOFAKTUR',
        'TGLFAKTUR',
        'TGLJT',
        'CUSTOMER',
        'PIUTANG',
        'BAYAR',
        'RETUR',
        'DISCOUNT',
        'SALDO',
        'CABANG',
        'KETERANGAN',
        'STATUS',
        'SOURCE',
        'NOJURNAL', // Added for journal linking
        'TGLLUNAS',
        'USER',
        'USER_UPDATE',
    ];

    protected $casts = [
        'TGLFAKTUR' => 'date',
        'TGLJT' => 'date',
        'TGLLUNAS' => 'date',
        'PIUTANG' => 'decimal:2',
        'BAYAR' => 'decimal:2',
        'RETUR' => 'decimal:2',
        'DISCOUNT' => 'decimal:2',
        'SALDO' => 'decimal:2',
    ];
}
