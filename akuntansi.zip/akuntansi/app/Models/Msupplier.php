<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Msupplier extends Model
{
    protected $table = 'msupplier';

    protected $primaryKey = 'SUPPLIER';

    public $incrementing = false;

    public $timestamps = false;

    protected $keyType = 'string';

    protected $fillable = [
        'SUPPLIER',
        'NAMA',
        'ALAMAT1',
        'ALAMAT2',
        'KOTA',
        'TELEPON',
        'FAX',
        'EMAIL',
        'KONTAK',
        'NOREK',
        'BANK',
        'ATASNAMA',
        'SALDO',
        'RETURAN',
        'FTOP',
        'DISC_REG',
    ];

    public function getDisplayNameAttribute(): string
    {
        return trim((string) $this->SUPPLIER) . ' - ' . (trim((string) $this->NAMA) ?: 'Tanpa Nama');
    }
}
