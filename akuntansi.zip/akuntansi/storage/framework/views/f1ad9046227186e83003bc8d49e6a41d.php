<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Kartu Piutang Per Faktur</title>
    <style>
        @page { size: 8.5in 11in; margin: 0.35in; }
        body { margin: 0; color: #111; font-family: Helvetica, Arial, sans-serif; font-size: 8.2pt; }
        <?php if($dotMatrix): ?>
        body { font-family: Courier, monospace; font-size: 8pt; }
        <?php endif; ?>
        .header { margin-bottom: 10pt; text-align: center; line-height: 1.35; }
        .company { font-size: 12pt; font-weight: bold; text-transform: uppercase; }
        .title { font-size: 11pt; font-weight: bold; }
        .meta { font-size: 8pt; }
        .card { page-break-inside: avoid; margin-bottom: 12pt; border: .7pt solid #222; }
        .card-head { padding: 5pt 6pt; background: #eee; border-bottom: .7pt solid #222; }
        .card-title { font-size: 9.5pt; font-weight: bold; }
        .card-sub { font-size: 7.8pt; margin-top: 2pt; }
        .summary { width: 100%; border-collapse: collapse; margin-top: 3pt; }
        .summary td { border: 0; padding: 1pt 0; }
        .summary .right { text-align: right; white-space: nowrap; }
        table.lines { width: 100%; border-collapse: collapse; table-layout: fixed; }
        table.lines th, table.lines td { border: .5pt solid #333; padding: 2.5pt 3pt; vertical-align: top; }
        table.lines th { background: #f3f3f3; font-size: 7.5pt; text-align: center; }
        .right { text-align: right; white-space: nowrap; }
        .center { text-align: center; }
        .bold { font-weight: bold; }
        .muted { color: #444; }
    </style>
</head>
<body>
<?php
    $money = static fn ($value) => number_format((float) $value, 2, ',', '.');
?>

<div class="header">
    <div class="company"><?php echo e(config('app.company_name', config('app.name'))); ?></div>
    <div class="title">KARTU PIUTANG PER FAKTUR</div>
    <div class="meta">
        Posisi <?php echo e(date('d/m/Y', strtotime($tanggalPosisi))); ?>

        <?php if($customer !== ''): ?> — Pelanggan: <?php echo e($customer); ?><?php endif; ?>
        <?php if(($nofaktur ?? '') !== ''): ?> — No. Faktur: <?php echo e($nofaktur); ?><?php endif; ?>
    </div>
</div>

<?php $__currentLoopData = $invoiceCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card">
        <div class="card-head">
            <div class="card-title"><?php echo e($card['invoice']->NOFAKTUR); ?></div>
            <div class="card-sub">
                <?php echo e($card['invoice']->CUSTOMER); ?>

                <?php if($card['customer_name']): ?> — <?php echo e($card['customer_name']); ?><?php endif; ?>
                · Tgl <?php echo e($card['invoice']->TGLFAKTUR?->format('d/m/Y')); ?>

                · JTP <?php echo e($card['invoice']->TGLJT?->format('d/m/Y') ?? '-'); ?>

                · <?php echo e($card['status']); ?>

                <?php if($card['journal_number']): ?>
                    · Jurnal <?php echo e($card['journal_number']); ?>

                <?php endif; ?>
            </div>
            <table class="summary">
                <tr>
                    <td>Nilai: <span class="bold"><?php echo e($money($card['invoice_amount'])); ?></span></td>
                    <td class="right">Terbayar: <span class="bold"><?php echo e($money($card['paid'])); ?></span></td>
                    <td class="right">Sisa: <span class="bold"><?php echo e($money($card['balance'])); ?></span></td>
                </tr>
            </table>
        </div>
        <table class="lines">
            <thead>
                <tr>
                    <th style="width:11%">Tanggal</th>
                    <th style="width:12%">Jenis</th>
                    <th style="width:16%">Referensi</th>
                    <th style="width:29%">Keterangan</th>
                    <th style="width:11%">Debit</th>
                    <th style="width:11%">Kredit</th>
                    <th style="width:10%">Saldo</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $card['lines']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="center"><?php echo e($line['date']?->format('d/m/Y') ?? '-'); ?></td>
                        <td class="center"><?php echo e($line['type'] === 'invoice' ? 'Invoice' : 'Pelunasan'); ?></td>
                        <td><?php echo e($line['reference']); ?></td>
                        <td><?php echo e($line['description']); ?></td>
                        <td class="right"><?php echo e($line['debit'] > 0 ? $money($line['debit']) : '-'); ?></td>
                        <td class="right"><?php echo e($line['credit'] > 0 ? $money($line['credit']) : '-'); ?></td>
                        <td class="right bold"><?php echo e($money($line['balance'])); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>
<?php /**PATH C:\LARAVEL_APP\akuntansi\resources\views/laporan/piutang_kartu_pdf.blade.php ENDPATH**/ ?>