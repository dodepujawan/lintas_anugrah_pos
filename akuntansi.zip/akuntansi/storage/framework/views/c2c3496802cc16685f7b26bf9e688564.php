<?php
$displayAmount = function ($value) {
if ($value < 0) {
    $num=number_format(abs($value), 2, ',' , '.' );
    return '<span class="currency">(</span>&nbsp;<span class="num">' . $num . '</span>' ;
    }

    $num=number_format($value, 2, ',' , '.' );
    return '<span class="num">' . $num . '</span>' ;
    };
    ?>

    <?php $__currentLoopData = $nodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $node): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    $indentClass=$level> 0 ? 'ps-' . min(5, $level + 2) : '';
    $indentStyle = $level > 0 ? 'padding-left: ' . ($level * 16) . 'px;' : '';
    $rowClass = $level === 0 ? 'table-light' : '';
    $amountClass = $node['coa']->tipe === 'Aset'
    ? 'text-primary'
    : ($node['coa']->tipe === 'Kewajiban' ? 'text-danger' : 'text-success');
    $displayLabel = $node['coa']->nama_akun;
    ?>
    <tr class="tree-row account-row <?php echo e($rowClass); ?>" data-parent-id="<?php echo e($parentId); ?>">
        <?php if($show_code ?? true): ?>
        <td class="px-3 code-col text-start"><?php echo e($node['coa']->kode_akun); ?></td>
        <?php endif; ?>
        <td class="px-3 <?php echo e($indentClass); ?>" style="<?php echo e($indentStyle); ?>">
            <?php if($mobile_code ?? false): ?>
            <span class="mobile-code"><?php echo e($node['coa']->kode_akun); ?></span>
            <?php endif; ?>
            <?php echo e($displayLabel); ?>

        </td>
        <td class="px-3 fw-bold amount <?php echo e($amountClass); ?>"><?php echo $displayAmount($node['subtotal']); ?></td>
    </tr>
    <?php if(!empty($node['children'])): ?>
    <?php echo $__env->make('laporan._coa_tree_rows', ['nodes' => $node['children'], 'level' => $level + 1, 'parentId' => $node['coa']->id, 'show_code' => $show_code ?? true, 'mobile_code' => $mobile_code ?? false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\LARAVEL_APP\akuntansi\resources\views/laporan/_coa_tree_rows.blade.php ENDPATH**/ ?>