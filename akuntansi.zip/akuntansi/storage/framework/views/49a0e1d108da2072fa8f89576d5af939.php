<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="auth-card">

        <!-- Logo & Header -->
        <div class="text-center mb-4">
            <div class="auth-logo mx-auto mb-3">
                📊
            </div>
            <h1 class="auth-title mb-1"><?php echo e(config('app.name')); ?></h1>
            <p class="auth-subtitle"><?php echo e(config('app.tagline')); ?></p>
        </div>

        <!-- Session Status -->
        <?php if(session('status')): ?>
        <div class="alert-success-auth mb-4">
            <i class="bi bi-check-circle me-2"></i><?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>

            <!-- Email / User ID -->
            <div class="mb-3">
                <label for="email" class="form-label">
                    <i class="bi bi-envelope me-1"></i> Email atau Username
                </label>
                <input id="email"
                    type="text"
                    name="email"
                    value="<?php echo e(old('email')); ?>"
                    class="form-control auth-input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    placeholder="email atau username"
                    required
                    autofocus
                    autocomplete="username">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Password -->
            <div class="mb-3">
                <label for="password" class="form-label">
                    <i class="bi bi-lock me-1"></i> Password
                </label>
                <div class="position-relative">
                    <input id="password"
                        type="password"
                        name="password"
                        class="form-control auth-input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="••••••••"
                        required
                        autocomplete="current-password">
                    <button type="button"
                        onclick="togglePassword()"
                        style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:#64748b;cursor:pointer;padding:0;">
                        <i class="bi bi-eye" id="eyeIcon"></i>
                    </button>
                </div>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Remember Me & Forgot Password -->
            <div class="d-flex align-items-center justify-content-between mb-4">
                <div class="form-check">
                    <input id="remember_me" type="checkbox" class="form-check-input" name="remember">
                    <label for="remember_me" class="form-check-label">Ingat saya</label>
                </div>
                <?php if(\Illuminate\Support\Facades\Route::has('password.request')): ?>
                <a href="<?php echo e(route('password.request')); ?>" class="auth-link">
                    Lupa password?
                </a>
                <?php endif; ?>
            </div>

            <!-- Submit -->
            <button type="submit" class="btn-auth">
                <i class="bi bi-box-arrow-in-right me-2"></i>Masuk
            </button>

        </form>

        <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()?->hasMenuPermission('register', 'create') && \Illuminate\Support\Facades\Route::has('register')): ?>
        <hr style="border-color:rgba(255,255,255,0.08);margin:1.25rem 0;">
        <div class="text-center">
            <p class="auth-subtitle mb-2" style="font-size:0.82rem;">Admin dapat membuat akun baru</p>
            <a href="<?php echo e(route('register')); ?>" class="btn-auth-outline">
                <i class="bi bi-person-plus me-2"></i>Daftar Akun Baru
            </a>
        </div>
        <?php endif; ?>
        <?php endif; ?>

        <!-- Footer -->
        <div class="text-center mt-4">
            <p class="auth-subtitle" style="font-size:0.78rem;">
                &copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?> &mdash; All rights reserved
            </p>
        </div>

    </div>

    <style>
        .btn-auth-outline {
            display: block;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 10px;
            color: #a5b4fc;
            font-weight: 600;
            font-size: 0.85rem;
            padding: 0.65rem 1.5rem;
            width: 100%;
            text-align: center;
            text-decoration: none;
            transition: all 0.2s;
        }

        .btn-auth-outline:hover {
            background: rgba(99, 102, 241, 0.15);
            border-color: rgba(99, 102, 241, 0.4);
            color: #c7d2fe;
        }
    </style>

    <script>
        function togglePassword() {
            var input = document.getElementById('password');
            var icon = document.getElementById('eyeIcon');
            if (input.type === 'password') {
                input.type = 'text';
                icon.className = 'bi bi-eye-slash';
            } else {
                input.type = 'password';
                icon.className = 'bi bi-eye';
            }
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\LARAVEL_APP\akuntansi\resources\views/auth/login.blade.php ENDPATH**/ ?>