<?php $__env->startSection('title', 'Audit Selisih'); ?>

<?php $__env->startSection('content'); ?>
<div class="audit-header d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
    <div>
        <h2 class="page-title mb-0"><i class="bi bi-search-heart me-2"></i>Audit Selisih</h2>
        <small class="text-muted">Mendeteksi perbedaan dan membuka sumber transaksi penyebabnya.</small>
    </div>
    <span class="badge bg-<?php echo e($summary['issues'] > 0 ? 'danger' : 'success'); ?> audit-result-badge">
        <?php echo e($summary['issues'] > 0 ? $summary['issues'].' temuan perlu diperiksa' : 'Tidak ada temuan'); ?>

    </span>
</div>

<div class="card audit-filter mb-3">
    <div class="card-body py-2">
        <form method="GET" action="<?php echo e(route('audit-selisih')); ?>" class="row g-2 align-items-end">
            <div class="col-6 col-md-3">
                <label class="form-label mb-1">Tanggal Awal</label>
                <input type="date" name="tanggal_awal" value="<?php echo e($tanggalAwal); ?>" class="form-control form-control-sm" required>
            </div>
            <div class="col-6 col-md-3">
                <label class="form-label mb-1">Tanggal Akhir</label>
                <input type="date" name="tanggal_akhir" value="<?php echo e($tanggalAkhir); ?>" class="form-control form-control-sm" required>
            </div>
            <div class="col-md-3">
                <label class="form-label mb-1">Jenis Pemeriksaan</label>
                <select name="jenis" class="form-select form-select-sm">
                    <option value="semua" <?php if($jenis === 'semua'): echo 'selected'; endif; ?>>Semua Temuan</option>
                    <option value="rekonsiliasi" <?php if($jenis === 'rekonsiliasi'): echo 'selected'; endif; ?>>Rekonsiliasi Piutang</option>
                    <option value="penjualan" <?php if($jenis === 'penjualan'): echo 'selected'; endif; ?>>Audit Penjualan</option>
                    <option value="jurnal" <?php if($jenis === 'jurnal'): echo 'selected'; endif; ?>>Konsistensi Jurnal</option>
                    <option value="sumber" <?php if($jenis === 'sumber'): echo 'selected'; endif; ?>>Sumber Transaksi</option>
                    <option value="duplikat" <?php if($jenis === 'duplikat'): echo 'selected'; endif; ?>>Referensi Ganda</option>
                </select>
            </div>
            <div class="col-md-3">
                <button class="btn btn-primary btn-sm"><i class="bi bi-search me-1"></i>Jalankan Audit</button>
            </div>
        </form>
    </div>
</div>

<div class="row g-2 audit-summary mb-3">
    <div class="col-6 col-lg-3"><div class="card h-100"><div class="card-body"><small class="text-muted">Pemeriksaan</small><div class="audit-number"><?php echo e($summary['checks']); ?></div></div></div></div>
    <div class="col-6 col-lg-3"><div class="card h-100 border-success"><div class="card-body"><small class="text-muted">Sesuai</small><div class="audit-number text-success"><?php echo e($summary['ok']); ?></div></div></div></div>
    <div class="col-6 col-lg-3"><div class="card h-100 <?php echo e($summary['issues'] ? 'border-danger' : 'border-success'); ?>"><div class="card-body"><small class="text-muted">Temuan Ditampilkan</small><div class="audit-number <?php echo e($summary['issues'] ? 'text-danger' : 'text-success'); ?>"><?php echo e($summary['issues']); ?></div></div></div></div>
    <div class="col-6 col-lg-3"><div class="card h-100 <?php echo e(abs($summary['difference']) > .01 ? 'border-danger' : 'border-success'); ?>"><div class="card-body"><small class="text-muted">Selisih Piutang</small><div class="audit-number <?php echo e(abs($summary['difference']) > .01 ? 'text-danger' : 'text-success'); ?>"><?php echo e(number_format($summary['difference'], 2, ',', '.')); ?></div></div></div></div>
</div>

<div class="card audit-impact mb-3 <?php echo e($summary['issues'] ? 'border-danger' : 'border-success'); ?>">
    <div class="card-body py-2">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
            <div>
                <small class="text-muted">Total Selisih Temuan</small>
                <div class="audit-total-selisih <?php echo e($summary['issues'] ? 'text-danger' : 'text-success'); ?>">
                    Rp <?php echo e(number_format($summary['total_selisih'], 2, ',', '.')); ?>

                </div>
            </div>
            <span class="badge bg-<?php echo e($summary['issues'] ? 'danger' : 'success'); ?>">
                <?php echo e($summary['issues'] ? 'Perlu ditindaklanjuti' : 'Aman'); ?>

            </span>
        </div>
        <div class="audit-impact-warning mt-2">
            <div class="fw-semibold mb-1">
                <i class="bi bi-exclamation-triangle me-1"></i>Peringatan akibat selisih
            </div>
            <ul class="mb-0 ps-3">
                <?php $__currentLoopData = $impactWarnings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warning): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($warning); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>

<div class="card mb-3">
    <div class="card-header py-2 fw-semibold">Ringkasan Pemeriksaan</div>
    <div class="table-responsive">
        <table class="table table-sm align-middle mb-0 audit-table">
            <thead class="table-light"><tr><th>Pemeriksaan</th><th>Status</th><th class="text-end">Buku Pembantu</th><th class="text-end">Buku Besar</th><th class="text-end">Selisih</th><th>Kesimpulan</th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $checks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="fw-semibold"><?php echo e($check['label']); ?></td>
                    <td><span class="badge bg-<?php echo e($check['status'] === 'ok' ? 'success' : ($check['status'] === 'warning' ? 'warning text-dark' : 'danger')); ?>"><?php echo e($check['status'] === 'ok' ? 'Sesuai' : 'Periksa'); ?></span></td>
                    <td class="text-end"><?php echo e($check['expected'] === null ? '-' : number_format($check['expected'], 2, ',', '.')); ?></td>
                    <td class="text-end"><?php echo e($check['actual'] === null ? '-' : number_format($check['actual'], 2, ',', '.')); ?></td>
                    <td class="text-end fw-semibold <?php echo e($check['difference'] !== null && abs($check['difference']) > .01 ? 'text-danger' : ''); ?>"><?php echo e($check['difference'] === null ? '-' : number_format($check['difference'], 2, ',', '.')); ?></td>
                    <td><?php echo e($check['message']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card">
    <div class="card-header py-2 d-flex justify-content-between align-items-center">
        <span class="fw-semibold">Daftar Temuan dan Sumber</span>
        <small class="text-muted">Klik Lacak untuk membuka data asal</small>
    </div>
    <div class="table-responsive d-none d-md-block">
        <table class="table table-hover align-middle mb-0 audit-table">
            <thead class="table-light"><tr><th>Jenis</th><th>Temuan</th><th>Penyebab</th><th>Penjelasan</th><th class="text-end">Nilai/Selisih</th><th class="text-end">Aksi</th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $filteredIssues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><span class="badge bg-<?php echo e($issue['severity'] === 'danger' ? 'danger' : 'warning text-dark'); ?>"><?php echo e(ucfirst($issue['category'])); ?></span></td>
                    <td class="fw-semibold"><?php echo e($issue['title']); ?></td>
                    <td class="audit-cause"><?php echo e($issue['cause'] ?? '-'); ?></td>
                    <td><?php echo e($issue['description']); ?></td>
                    <td class="text-end text-nowrap"><?php echo e($issue['amount'] === null ? '-' : number_format($issue['amount'], 2, ',', '.')); ?></td>
                    <td class="text-end"><a href="<?php echo e($issue['url']); ?>" class="btn btn-sm btn-outline-primary text-nowrap"><i class="bi bi-box-arrow-up-right me-1"></i><?php echo e($issue['action']); ?></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center text-success py-4"><i class="bi bi-check-circle me-1"></i>Tidak ada temuan untuk filter ini.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="d-md-none audit-mobile-list">
        <?php $__empty_1 = true; $__currentLoopData = $filteredIssues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="audit-mobile-item">
                <div class="d-flex justify-content-between gap-2"><strong><?php echo e($issue['title']); ?></strong><span class="badge bg-<?php echo e($issue['severity'] === 'danger' ? 'danger' : 'warning text-dark'); ?>"><?php echo e(ucfirst($issue['category'])); ?></span></div>
                <div class="audit-mobile-cause mt-1"><span class="fw-semibold">Penyebab:</span> <?php echo e($issue['cause'] ?? '-'); ?></div>
                <div class="text-muted mt-1"><?php echo e($issue['description']); ?></div>
                <?php if($issue['amount'] !== null): ?><div class="fw-semibold text-danger mt-1"><?php echo e(number_format($issue['amount'], 2, ',', '.')); ?></div><?php endif; ?>
                <a href="<?php echo e($issue['url']); ?>" class="btn btn-sm btn-outline-primary w-100 mt-2"><?php echo e($issue['action']); ?></a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-center text-success py-4"><i class="bi bi-check-circle me-1"></i>Tidak ada temuan.</div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .audit-header .page-title { font-size: 1.3rem; }
    .audit-header small { font-size: .86rem; }
    .audit-result-badge { padding: .52rem .75rem; font-size: .8rem; }
    .audit-filter .form-label, .audit-filter .form-control, .audit-filter .form-select, .audit-filter .btn { font-size: .8rem; }
    .audit-summary .card-body { padding: .55rem .7rem; }
    .audit-summary small, .audit-impact small, .card-header small { font-size: .8rem; }
    .audit-number { margin-top: .1rem; font-size: 1.12rem; line-height: 1.15; font-weight: 700; overflow-wrap: anywhere; }
    .audit-total-selisih { font-size: 1.28rem; line-height: 1.15; font-weight: 800; overflow-wrap: anywhere; }
    .audit-impact-warning { font-size: .82rem; line-height: 1.38; }
    .audit-impact-warning li + li { margin-top: .15rem; }
    .audit-table th, .audit-table td { padding: .4rem .48rem; font-size: .78rem; line-height: 1.24; }
    .audit-table .badge { font-size: .68rem; }
    .audit-table .btn-sm { font-size: .74rem; padding: .22rem .42rem; }
    .audit-cause { min-width: 180px; font-weight: 600; color: #842029; }
    .audit-mobile-item { padding: .78rem; border-bottom: 1px solid #dee2e6; font-size: .82rem; line-height: 1.35; }
    .audit-mobile-cause { color: #842029; }
    @media (max-width: 767.98px) {
        .audit-header .page-title { font-size: 1.15rem; }
        .audit-header small { font-size: .78rem; line-height: 1.3; display: block; }
        .audit-result-badge { width: 100%; text-align: center; font-size: .76rem; }
        .audit-filter .form-label, .audit-filter .form-control, .audit-filter .form-select, .audit-filter .btn { font-size: .78rem; }
        .audit-summary .card-body { padding: .52rem .6rem; }
        .audit-summary small { font-size: .72rem; }
        .audit-summary .audit-number { font-size: .96rem; }
        .audit-total-selisih { font-size: 1.08rem; }
        .audit-impact-warning { font-size: .78rem; }
        .audit-table th, .audit-table td { padding: .36rem .42rem; font-size: .74rem; }
        .audit-mobile-item { font-size: .82rem; }
        .audit-filter .btn { width: 100%; }
    }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\LARAVEL_APP\akuntansi\resources\views/audit-selisih/index.blade.php ENDPATH**/ ?>