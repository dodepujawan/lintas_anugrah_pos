

<?php $__env->startSection('title', 'Daftar Jurnal'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .filter-card {
        background: #f8f9fa;
    }

    .journal-list-table {
        table-layout: fixed;
        min-width: 900px;
        margin-bottom: 0;
    }

    .journal-list-table .journal-number-col { width: 14%; }
    .journal-list-table .journal-date-col { width: 9%; }
    .journal-list-table .journal-description-col { width: 27%; }
    .journal-list-table .journal-amount-col { width: 12%; }
    .journal-list-table .journal-status-col { width: 11%; }
    .journal-list-table .journal-action-col { width: 15%; }

    .journal-list-table th {
        padding: .55rem .6rem;
        font-size: .82rem;
        white-space: nowrap;
    }

    .journal-list-table td {
        padding: .5rem .6rem;
        font-size: .88rem;
        line-height: 1.25;
        vertical-align: middle;
    }

    .journal-list-table td:nth-child(1) {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
        font-size: .84rem;
        font-weight: 400;
        white-space: nowrap;
    }

    .journal-list-table td:nth-child(2) {
        font-size: .84rem;
        white-space: nowrap;
        font-variant-numeric: tabular-nums;
        padding-left: .8rem;
    }

    .journal-list-table td:nth-child(3) {
        white-space: normal;
        overflow-wrap: anywhere;
        word-break: normal;
    }

    .journal-list-table td:nth-child(4),
    .journal-list-table td:nth-child(5) {
        font-size: .84rem;
        white-space: nowrap;
        font-variant-numeric: tabular-nums;
    }

    .journal-list-table td:nth-child(6) {
        white-space: normal;
    }

    .journal-list-table td:nth-child(6) .badge {
        display: inline-block;
        max-width: 100%;
        font-size: .72rem;
        white-space: normal;
        line-height: 1.1;
        text-align: center;
    }

    .journal-actions {
        display: flex;
        align-items: center;
        flex-wrap: nowrap;
        gap: .2rem;
        white-space: nowrap;
    }

    .journal-actions form { margin: 0; }

    .journal-actions .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 28px;
        height: 28px;
        padding: 0;
        font-size: .72rem;
    }

    .journal-list-table tr.journal-highlight-row > td {
        background: #dcfce7 !important;
        box-shadow: inset 0 1px 0 #86efac, inset 0 -1px 0 #86efac;
    }

    .journal-list-table tr.journal-highlight-row > td:first-child {
        border-left: 4px solid #16a34a;
    }

</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-12 d-flex justify-content-between align-items-center">
        <h2><i class="bi bi-journal-text"></i> Daftar Jurnal</h2>
        <div class="d-flex gap-2">
            <a href="<?php echo e(route('panduan.jurnal_umum')); ?>" class="btn btn-outline-info">
                <i class="bi bi-book"></i> Panduan Input
            </a>
            <a href="<?php echo e(route('jurnal.create')); ?>" class="btn btn-primary">
                <i class="bi bi-plus-circle"></i> Tambah Jurnal
            </a>
        </div>
    </div>
</div>

<div class="card filter-card mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('jurnal.index')); ?>" class="row g-3">
            <div class="col-md-3">
                <label for="tanggal_awal" class="form-label">Tanggal Awal</label>
                <input type="date" class="form-control" id="tanggal_awal" name="tanggal_awal" value="<?php echo e(request('tanggal_awal', $tanggalAwal)); ?>">
            </div>
            <div class="col-md-3">
                <label for="tanggal_akhir" class="form-label">Tanggal Akhir</label>
                <input type="date" class="form-control" id="tanggal_akhir" name="tanggal_akhir" value="<?php echo e(request('tanggal_akhir', $tanggalAkhir)); ?>">
            </div>
            <div class="col-md-2">
                <label for="status" class="form-label">Status</label>
                <select name="status" class="form-select" id="status">
                    <option value="">Semua Status</option>
                    <option value="posted" <?php echo e(request('status') == 'posted' ? 'selected' : ''); ?>>Posted</option>
                    <option value="draft" <?php echo e(request('status') == 'draft' ? 'selected' : ''); ?>>Draft</option>
                    <option value="void" <?php echo e(request('status') == 'void' ? 'selected' : ''); ?>>Void</option>
                </select>
            </div>
            <div class="col-md-4">
                <label for="search" class="form-label">Search</label>
                <input type="search" class="form-control" id="search" name="search" value="<?php echo e(request('search')); ?>" placeholder="No jurnal, referensi, akun, keterangan">
            </div>
            <div class="col-12">
                <button type="submit" class="btn btn-primary"><i class="bi bi-search"></i> Filter</button>
                <a href="<?php echo e(route('jurnal.index')); ?>" class="btn btn-secondary"><i class="bi bi-x-circle"></i> Reset</a>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover journal-list-table">
                <colgroup>
                    <col class="journal-number-col">
                    <col class="journal-date-col">
                    <col class="journal-description-col">
                    <col class="journal-amount-col">
                    <col class="journal-amount-col">
                    <col class="journal-status-col">
                    <col class="journal-action-col">
                </colgroup>
                <thead>
                    <tr>
                        <th>No. Jurnal</th>
                        <th>Tanggal</th>
                        <th>Keterangan</th>
                        <th class="text-end">Total Debit</th>
                        <th class="text-end">Total Kredit</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $jurnals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurnal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php ($canEdit = $jurnal->status !== App\Models\Jurnal::STATUS_VOID && !in_array((int) $jurnal->tanggal->year, $lockedYears, true)); ?>
                    <?php ($isHighlighted = (string) request('highlight') === (string) $jurnal->id); ?>
                    <tr id="jurnal-<?php echo e($jurnal->id); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['journal-highlight-row' => $isHighlighted]); ?>">
                        <td><?php echo e($jurnal->no_jurnal); ?></td>
                        <td><?php echo e($jurnal->tanggal->format('d/m/Y')); ?></td>
                        <td><?php echo e($jurnal->keterangan); ?></td>
                        <td class="text-end"><?php echo e(number_format($jurnal->total_debit, 2)); ?></td>
                        <td class="text-end"><?php echo e(number_format($jurnal->total_kredit, 2)); ?></td>
                        <td>
                            <?php if($jurnal->status === App\Models\Jurnal::STATUS_POSTED): ?>
                            <span class="badge bg-success">Posted</span>
                            <?php elseif($jurnal->status === App\Models\Jurnal::STATUS_VOID): ?>
                            <span class="badge bg-danger">Void</span>
                            <?php else: ?>
                            <span class="badge bg-warning">Draft</span>
                            <?php endif; ?>
                            <?php if(abs((float) $jurnal->total_debit - (float) $jurnal->total_kredit) > 0.01): ?>
                            <div class="mt-1"><span class="badge bg-warning text-dark">Tidak Balance</span></div>
                            <?php endif; ?>
                        </td>
                        <td><div class="journal-actions">
                            <a href="<?php echo e(route('jurnal.show', $jurnal->id)); ?>" class="btn btn-sm btn-info" title="Detail">
                                <i class="bi bi-eye"></i>
                            </a>
                            <?php if($canEdit): ?>
                            <a href="<?php echo e(route('jurnal.edit', $jurnal->id)); ?>" class="btn btn-sm btn-warning" title="Edit">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <?php endif; ?>
                            <?php if(!$jurnal->is_posted): ?>
                            <form action="<?php echo e(route('jurnal.post', $jurnal->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Posting jurnal ini?')">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-success" title="Posting">
                                    <i class="bi bi-check-lg"></i>
                                </button>
                            </form>
                            <form action="<?php echo e(route('jurnal.destroy', $jurnal->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus Draft <?php echo e($jurnal->no_jurnal); ?>? Semua item jurnal di dalam Draft ini akan ikut dihapus dan tindakan ini tidak dapat dibatalkan.')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" title="Hapus">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                            <?php endif; ?>
                        </div></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center">Belum ada data jurnal</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="d-flex justify-content-center mt-3">
            <?php echo e($jurnals->links()); ?>

        </div>
    </div>
</div>

<?php if(request('highlight')): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var row = document.getElementById('jurnal-<?php echo e(request('highlight')); ?>');
    if (row) {
        row.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    if (window.history && window.history.replaceState) {
        window.history.replaceState({}, '', '<?php echo e(route('jurnal.index')); ?>');
    }
});
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\LARAVEL_APP\akuntansi\resources\views/jurnal/index.blade.php ENDPATH**/ ?>