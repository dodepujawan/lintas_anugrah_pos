<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\SettingsController;

use App\Http\Controllers\CoaController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\CoaSaldoNormalAuditController;
use App\Http\Controllers\JurnalController;
use App\Http\Controllers\LaporanController;

use App\Http\Controllers\PiutangController;
use App\Http\Controllers\PelunasanPiutangController;
use App\Http\Controllers\HutangController;
use App\Http\Controllers\PelunasanHutangController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PanduanController;
use App\Http\Controllers\PeriodLockController;
use App\Http\Controllers\AuditLogController;
use App\Http\Controllers\ValidationDashboardController;
use App\Http\Controllers\ImportDataController;
use App\Http\Controllers\LaporanPiutangController;
use App\Http\Controllers\LaporanPenjualanController;
use App\Http\Controllers\PiutangBerjalanController;
use App\Http\Controllers\LaporanHutangController;
use App\Http\Controllers\PenjualanHostingController;
use App\Http\Controllers\DriverController;
use App\Http\Controllers\SupplierController;
use App\Http\Controllers\DriverReceivableController;
use App\Http\Controllers\DriverPaymentController;
use App\Http\Controllers\DriverOpeningReceivableController;
use App\Http\Controllers\DriverReceivableReportController;
use App\Http\Controllers\AuditSelisihController;

Route::get('/', function () {
    if (auth()->check()) {
        return redirect()->route(auth()->user()->defaultAuthorizedRoute());
    }

    return redirect()->route('login');
});

Route::get('/dashboard', [DashboardController::class, 'index'])
    ->middleware(['auth', 'verified'])
    ->name('dashboard');

Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('customers/duplicates', [CustomerController::class, 'duplicates'])->name('customers.duplicates');
    Route::get('customers/duplicates/export', [CustomerController::class, 'exportDuplicates'])->name('customers.duplicates.export');
    Route::get('customers/lookup', [CustomerController::class, 'lookup'])->name('customers.lookup');
    Route::post('customers/merge', [CustomerController::class, 'merge'])->name('customers.merge');
    Route::resource('customers', CustomerController::class)->except('show');
    Route::resource('suppliers', SupplierController::class)->except('show');
    Route::resource('drivers', DriverController::class)->except('show');
    Route::resource('driver-receivables', DriverReceivableController::class)->except('show');
    Route::get('driver-receivables/{driver_receivable}', [DriverReceivableController::class, 'show'])->name('driver-receivables.show');
    Route::get('driver-opening-receivables-export', [DriverOpeningReceivableController::class, 'export'])->name('driver-opening-receivables.export');
    Route::resource('driver-opening-receivables', DriverOpeningReceivableController::class)->except('show');
    Route::get('driver-payments', [DriverPaymentController::class, 'index'])->name('driver-payments.index');
    Route::get('driver-payments/create', [DriverPaymentController::class, 'create'])->name('driver-payments.create');
    Route::get('driver-payments/{driver_payment}/pdf', [DriverPaymentController::class, 'receiptPdf'])->name('driver-payments.pdf');
    Route::get('driver-payments/{driver_payment}/edit', [DriverPaymentController::class, 'edit'])->name('driver-payments.edit');
    Route::post('driver-payments', [DriverPaymentController::class, 'store'])->name('driver-payments.store');
    Route::put('driver-payments/{driver_payment}', [DriverPaymentController::class, 'update'])->name('driver-payments.update');
    Route::post('driver-payments/{driver_payment}/void', [DriverPaymentController::class, 'void'])->name('driver-payments.void');
    Route::get('driver-payments/{driver_payment}', [DriverPaymentController::class, 'show'])->name('driver-payments.show');
    Route::get('laporan/piutang-sopir/export', [DriverReceivableReportController::class, 'export'])->name('laporan.driver-receivables.export');
    Route::get('laporan/piutang-sopir/pdf', [DriverReceivableReportController::class, 'pdf'])->name('laporan.driver-receivables.pdf');
    Route::get('laporan/piutang-sopir', [DriverReceivableReportController::class, 'index'])->name('laporan.driver-receivables');
    Route::get('penjualan-hosting', [PenjualanHostingController::class, 'index'])->name('penjualan-hosting.index');
    Route::get('penjualan-hosting/export-bermasalah', [PenjualanHostingController::class, 'exportProblems'])->name('penjualan-hosting.export-problems');
    Route::get('penjualan-hosting/export-posted', [PenjualanHostingController::class, 'exportPosted'])->name('penjualan-hosting.export-posted');
    Route::post('penjualan-hosting/post', [PenjualanHostingController::class, 'post'])->name('penjualan-hosting.post');
    Route::post('penjualan-hosting/{invoice}/rejurnal', [PenjualanHostingController::class, 'repost'])->name('penjualan-hosting.repost');
    Route::post('penjualan-hosting/{invoice}/void', [PenjualanHostingController::class, 'void'])->name('penjualan-hosting.void');
    Route::post('penjualan-hosting/{invoice}/revoid', [PenjualanHostingController::class, 'revoid'])->name('penjualan-hosting.revoid');
    Route::get('/settings', [SettingsController::class, 'index'])->name('settings.index');
    Route::post('/settings/users', [SettingsController::class, 'store'])->name('settings.users.store');
    Route::put('/settings/users/{user}', [SettingsController::class, 'update'])->name('settings.users.update');
    Route::delete('/settings/users/{user}', [SettingsController::class, 'destroy'])->name('settings.users.destroy');

    Route::post('/settings/roles', [SettingsController::class, 'storeRole'])->name('settings.roles.store');
    Route::put('/settings/roles/{role}', [SettingsController::class, 'updateRole'])->name('settings.roles.update');
    Route::delete('/settings/roles/{role}', [SettingsController::class, 'destroyRole'])->name('settings.roles.destroy');

    Route::post('/settings/menus', [SettingsController::class, 'storeMenu'])->name('settings.menus.store');
    Route::put('/settings/menus/{menu}', [SettingsController::class, 'updateMenu'])->name('settings.menus.update');
    Route::delete('/settings/menus/{menu}', [SettingsController::class, 'destroyMenu'])->name('settings.menus.destroy');

    Route::post('/settings/roles/{role}/permissions', [SettingsController::class, 'updateRolePermissions'])->name('settings.roles.permissions.update');

    Route::get('period-locks', [PeriodLockController::class, 'index'])->name('period-locks.index');
    Route::post('period-locks', [PeriodLockController::class, 'store'])->name('period-locks.store');
    Route::delete('period-locks/{year}', [PeriodLockController::class, 'destroy'])->name('period-locks.destroy');
    Route::get('audit-logs', [AuditLogController::class, 'index'])->name('audit-logs.index');
    Route::get('audit-logs/export', [AuditLogController::class, 'export'])->name('audit-logs.export');
    Route::get('validation-dashboard', [ValidationDashboardController::class, 'index'])->name('validation-dashboard');
    Route::get('audit-selisih', [AuditSelisihController::class, 'index'])->name('audit-selisih');
    Route::get('import-data', [ImportDataController::class, 'index'])->name('import-data.index');
    Route::get('import-data/template/{type}', [ImportDataController::class, 'template'])->name('import-data.template');
    Route::post('import-data/{type}', [ImportDataController::class, 'store'])->name('import-data.store');

    // User management
    Route::resource('users', UserController::class);
    Route::post('users/{user}/reset-password', [UserController::class, 'resetPassword'])->name('users.reset-password');

    // Backup
    Route::get('backup', [App\Http\Controllers\BackupController::class, 'index'])->name('backup');
    Route::post('backup/run', [App\Http\Controllers\BackupController::class, 'run'])->name('backup.run');
    Route::get('backup/download/{file}', [App\Http\Controllers\BackupController::class, 'download'])->name('backup.download');

    /*
    |--------------------------------------------------------------------------
    | COA
    |--------------------------------------------------------------------------
    */
    Route::get('coa/export', [CoaController::class, 'export'])->name('coa.export');
    Route::resource('coa', CoaController::class);

    /*
    |--------------------------------------------------------------------------
    | ACCOUNT MAPPING
    |--------------------------------------------------------------------------
    */
    Route::get('account-mappings', [App\Http\Controllers\AccountMappingController::class, 'index'])
        ->name('account-mappings.index');
    Route::post('account-mappings', [App\Http\Controllers\AccountMappingController::class, 'store'])
        ->name('account-mappings.store');

    Route::get('coa-saldo-normal', [CoaSaldoNormalAuditController::class, 'index'])
        ->name('coa-saldo-normal');
    Route::post('coa-saldo-normal/fix', [CoaSaldoNormalAuditController::class, 'fix'])
        ->name('coa-saldo-normal.fix');

    /*
    |--------------------------------------------------------------------------
    | JURNAL
    |--------------------------------------------------------------------------
    */
    Route::post('jurnal/draft/save', [JurnalController::class, 'saveDraft'])->name('jurnal.draft.save');

    Route::get('jurnal/{jurnal}/pdf', [JurnalController::class, 'receiptPdf'])->name('jurnal.pdf');

    Route::resource('jurnal', JurnalController::class);

    Route::post('jurnal/{jurnal}/post', [JurnalController::class, 'post'])->name('jurnal.post');
    Route::post('jurnal/{jurnal}/void', [JurnalController::class, 'void'])->name('jurnal.void');

    /*
    |--------------------------------------------------------------------------
    | SALDO AWAL AKUN
    |--------------------------------------------------------------------------
    */
    Route::post('saldo-awal/draft/save', [App\Http\Controllers\SaldoAwalController::class, 'saveDraft'])->name('saldo-awal.draft.save');
    Route::get('saldo-awal/export', [App\Http\Controllers\SaldoAwalController::class, 'export'])->name('saldo-awal.export');
    Route::get('saldo-awal/pdf', [App\Http\Controllers\SaldoAwalController::class, 'pdf'])->name('saldo-awal.pdf');
    Route::get('saldo-awal/{saldo_awal}/pdf', [App\Http\Controllers\SaldoAwalController::class, 'pdfDetail'])->name('saldo-awal.detail.pdf');
    Route::resource('saldo-awal', App\Http\Controllers\SaldoAwalController::class);
    Route::post('saldo-awal/{saldo_awal}/post', [App\Http\Controllers\SaldoAwalController::class, 'post'])->name('saldo-awal.post');
    Route::post('saldo-awal/{saldo_awal}/reopen', [App\Http\Controllers\SaldoAwalController::class, 'reopen'])->name('saldo-awal.reopen');

    /*
    |--------------------------------------------------------------------------
    | JURNAL PENYESUAIAN
    |--------------------------------------------------------------------------
    */
    Route::post('jurnal-penyesuaian/draft/save', [App\Http\Controllers\JurnalPenyesuaianController::class, 'saveDraft'])->name('jurnal-penyesuaian.draft.save');
    Route::get('jurnal-penyesuaian/export', [App\Http\Controllers\JurnalPenyesuaianController::class, 'export'])->name('jurnal-penyesuaian.export');
    Route::get('jurnal-penyesuaian/pdf', [App\Http\Controllers\JurnalPenyesuaianController::class, 'pdf'])->name('jurnal-penyesuaian.pdf');
    Route::resource('jurnal-penyesuaian', App\Http\Controllers\JurnalPenyesuaianController::class);
    Route::post('jurnal-penyesuaian/{jurnal_penyesuaian}/post', [App\Http\Controllers\JurnalPenyesuaianController::class, 'post'])->name('jurnal-penyesuaian.post');

    /*
    |--------------------------------------------------------------------------
    | PIUTANG (SALDO AWAL)
    |--------------------------------------------------------------------------
    */
    Route::get('piutang-berjalan', [PiutangBerjalanController::class, 'index'])
        ->name('piutang-berjalan.index');
    Route::get('piutang-berjalan/create', [PiutangBerjalanController::class, 'create'])
        ->name('piutang-berjalan.create');
    Route::post('piutang-berjalan', [PiutangBerjalanController::class, 'store'])
        ->name('piutang-berjalan.store');
    Route::get('piutang-berjalan/{piutang}/edit', [PiutangBerjalanController::class, 'edit'])->name('piutang-berjalan.edit');
    Route::put('piutang-berjalan/{piutang}', [PiutangBerjalanController::class, 'update'])->name('piutang-berjalan.update');
    Route::delete('piutang-berjalan/{piutang}', [PiutangBerjalanController::class, 'destroy'])->name('piutang-berjalan.destroy');

    Route::get('piutang/pdf', [PiutangController::class, 'pdf'])->name('piutang.pdf');
    Route::get(
        'piutang',
        [PiutangController::class, 'index']
    )->name('piutang.index');

    Route::get(
        'piutang/create',
        [PiutangController::class, 'create']
    )->name('piutang.create');

    Route::get('piutang-export', [PiutangController::class, 'export'])->name('piutang.export');

    Route::post(
        'piutang',
        [PiutangController::class, 'store']
    )->name('piutang.store');

    Route::get(
        'piutang/pelanggan/search',
        [PiutangController::class, 'searchPelanggan']
    )->name('piutang.search-pelanggan');

    Route::get('piutang/{piutang}/edit', [PiutangController::class, 'edit'])->name('piutang.edit');
    Route::put('piutang/{piutang}', [PiutangController::class, 'update'])->name('piutang.update');
    Route::delete('piutang/{piutang}', [PiutangController::class, 'destroy'])->name('piutang.destroy');
    Route::get('piutang/{piutang}', [PiutangController::class, 'show'])->name('piutang.show');

    /*
    |--------------------------------------------------------------------------
    | PELUNASAN PIUTANG
    |--------------------------------------------------------------------------
    */
    // Custom routes first (more specific)
    Route::get(
        'pelunasan-piutang/search-customer',
        [PelunasanPiutangController::class, 'searchCustomer']
    )->name('pelunasan-piutang.search-customer');

    Route::get(
        'pelunasan-piutang/customer-invoices',
        [PelunasanPiutangController::class, 'customerInvoices']
    )->name('pelunasan-piutang.customer-invoices');
    Route::post('pelunasan-piutang/{pelunasan_piutang}/void', [PelunasanPiutangController::class, 'void'])->name('pelunasan-piutang.void');
    Route::get('pelunasan-piutang/{pelunasan_piutang}/export', [PelunasanPiutangController::class, 'exportReceipt'])->name('pelunasan-piutang.export');
    Route::get('pelunasan-piutang/{pelunasan_piutang}/pdf', [PelunasanPiutangController::class, 'receiptPdf'])->name('pelunasan-piutang.pdf');

    // Resource routes (less specific)
    Route::resource(
        'pelunasan-piutang',
        PelunasanPiutangController::class
    )->only([
        'index',
        'create',
        'store',
        'show',
        'edit',
        'update'
    ]);

    /*
    |--------------------------------------------------------------------------
    | HUTANG
    |--------------------------------------------------------------------------
    */
    Route::get('saldo-awal-hutang', [HutangController::class, 'openingIndex'])
        ->name('saldo-awal-hutang.index');
    Route::get('saldo-awal-hutang/export/excel', [HutangController::class, 'exportSaldoAwal'])
        ->name('saldo-awal-hutang.export');
    Route::get('saldo-awal-hutang/pdf', [HutangController::class, 'pdfSaldoAwal'])->name('saldo-awal-hutang.pdf');
    Route::get('saldo-awal-hutang/create', [HutangController::class, 'createSaldoAwal'])
        ->name('saldo-awal-hutang.create');
    Route::post('saldo-awal-hutang', [HutangController::class, 'storeSaldoAwal'])
        ->name('saldo-awal-hutang.store');
    Route::get('saldo-awal-hutang/{hutang}/edit', [HutangController::class, 'editSaldoAwal'])->name('saldo-awal-hutang.edit');
    Route::put('saldo-awal-hutang/{hutang}', [HutangController::class, 'updateSaldoAwal'])->name('saldo-awal-hutang.update');
    Route::delete('saldo-awal-hutang/{hutang}', [HutangController::class, 'destroySaldoAwal'])->name('saldo-awal-hutang.destroy');
    Route::get('hutang/supplier/search', [HutangController::class, 'searchSupplier'])
        ->name('hutang.search-supplier');
    Route::resource('hutang', HutangController::class)
        ->only(['index', 'create', 'store', 'show', 'edit', 'update', 'destroy']);

    /*
    |--------------------------------------------------------------------------
    | PELUNASAN HUTANG
    |--------------------------------------------------------------------------
    */
    Route::get('pelunasan-hutang/search-supplier', [PelunasanHutangController::class, 'searchSupplier'])
        ->name('pelunasan-hutang.search-supplier');
    Route::get('pelunasan-hutang/supplier-invoices', [PelunasanHutangController::class, 'supplierInvoices'])
        ->name('pelunasan-hutang.supplier-invoices');
    Route::post('pelunasan-hutang/{pelunasan_hutang}/void', [PelunasanHutangController::class, 'void'])->name('pelunasan-hutang.void');
    Route::resource('pelunasan-hutang', PelunasanHutangController::class)
        ->only(['index', 'create', 'store', 'show', 'edit', 'update', 'destroy']);

    /*
    |--------------------------------------------------------------------------
    | LAPORAN
    |--------------------------------------------------------------------------
    */
    Route::get(
        '/laporan',
        [LaporanController::class, 'index']
    )->name('laporan.index');

    Route::get('/laporan/piutang', [LaporanPiutangController::class, 'index'])
        ->name('laporan.piutang');
    Route::get('/laporan/piutang/export', [LaporanPiutangController::class, 'export'])
        ->name('laporan.piutang.export');
    Route::get('/laporan/piutang/pdf', [LaporanPiutangController::class, 'pdf'])
        ->name('laporan.piutang.pdf');
    Route::get('/laporan/penjualan', [LaporanPenjualanController::class, 'index'])
        ->name('laporan.penjualan');
    Route::get('/laporan/penjualan/export', [LaporanPenjualanController::class, 'export'])
        ->name('laporan.penjualan.export');
    Route::get('/laporan/penjualan/pdf', [LaporanPenjualanController::class, 'pdf'])
        ->name('laporan.penjualan.pdf');
    Route::get('/laporan/hutang', [LaporanHutangController::class, 'index'])->name('laporan.hutang');
    Route::get('/laporan/hutang/export', [LaporanHutangController::class, 'export'])->name('laporan.hutang.export');
    Route::get('/laporan/hutang/pdf', [LaporanHutangController::class, 'pdf'])->name('laporan.hutang.pdf');

    /*
    |--------------------------------------------------------------------------
    | PANDUAN (Markdown)
    |--------------------------------------------------------------------------
    */
    Route::get(
        '/panduan/tutup-buku',
        [PanduanController::class, 'tutupBuku']
    )->name('panduan.tutup_buku');

    Route::get(
        '/panduan/jurnal-umum',
        [PanduanController::class, 'jurnalUmum']
    )->name('panduan.jurnal_umum');

    Route::get(
        '/panduan/jurnal-penyesuaian',
        [PanduanController::class, 'jurnalPenyesuaian']
    )->name('panduan.jurnal_penyesuaian');

    Route::get(
        '/panduan/pelunasan-piutang',
        [PanduanController::class, 'pelunasanPiutang']
    )->name('panduan.pelunasan_piutang');

    Route::get(
        '/panduan/piutang-sopir',
        [PanduanController::class, 'piutangSopir']
    )->name('panduan.piutang_sopir');

    Route::get('/panduan/transaksi/{slug}', [PanduanController::class, 'transaksi'])
        ->name('panduan.transaksi');

    Route::get(
        '/laporan/jurnal-umum',
        [LaporanController::class, 'jurnalUmum']
    )->name('laporan.jurnal_umum');

    Route::get(
        '/laporan/jurnal-umum/excel',
        [LaporanController::class, 'exportJurnalUmum']
    )->name('laporan.jurnal_umum.excel');

    Route::get(
        '/laporan/coa',
        [LaporanController::class, 'coa']
    )->name('laporan.coa');

    Route::get(
        '/laporan/coa/excel',
        [LaporanController::class, 'exportCoa']
    )->name('laporan.coa.excel');

    Route::get(
        '/laporan/buku-besar',
        [LaporanController::class, 'bukuBesar']
    )->name('laporan.buku_besar');

    Route::get(
        '/laporan/buku-besar/excel',
        [LaporanController::class, 'exportBukuBesar']
    )->name('laporan.buku_besar.excel');

    Route::get(
        '/laporan/buku-besar/pdf',
        [LaporanController::class, 'exportBukuBesarPdf']
    )->name('laporan.buku_besar.pdf');

    Route::get(
        '/laporan/biaya',
        [LaporanController::class, 'biaya']
    )->name('laporan.biaya');

    Route::get(
        '/laporan/biaya/excel',
        [LaporanController::class, 'exportBiaya']
    )->name('laporan.biaya.excel');

    Route::get(
        '/laporan/neraca',
        [LaporanController::class, 'neraca']
    )->name('laporan.neraca');

    Route::get(
        '/laporan/neraca/excel',
        [LaporanController::class, 'exportNeraca']
    )->name('laporan.neraca.excel');

    Route::get(
        '/laporan/neraca/pdf',
        [LaporanController::class, 'exportNeracaPdf']
    )->name('laporan.neraca.pdf');

    Route::get(
        '/laporan/neraca-saldo',
        [LaporanController::class, 'neracaSaldo']
    )->name('laporan.neraca_saldo');

    Route::get(
        '/laporan/neraca-saldo/excel',
        [LaporanController::class, 'exportNeracaSaldo']
    )->name('laporan.neraca_saldo.excel');

    Route::get(
        '/laporan/arus-kas',
        [LaporanController::class, 'arusKas']
    )->name('laporan.arus_kas');

    Route::get(
        '/laporan/arus-kas/excel',
        [LaporanController::class, 'exportArusKas']
    )->name('laporan.arus_kas.excel');

    Route::get(
        '/laporan/tutup-buku',
        [LaporanController::class, 'tutupBuku']
    )->name('laporan.tutup_buku');

    Route::get(
        '/laporan/tutup-buku/excel',
        [LaporanController::class, 'exportTutupBuku']
    )->name('laporan.tutup_buku.excel');

    Route::get(
        '/laporan/perubahan-ekuitas',
        [LaporanController::class, 'perubahanEkuitas']
    )->name('laporan.perubahan_ekuitas');

    Route::get(
        '/laporan/perubahan-ekuitas/excel',
        [LaporanController::class, 'exportPerubahanEkuitas']
    )->name('laporan.perubahan_ekuitas.excel');

    Route::post(
        '/laporan/tutup-buku/generate-jurnal',
        [LaporanController::class, 'generateClosingJournal']
    )->name('laporan.tutup_buku.generate_jurnal');

    Route::post(
        '/laporan/tutup-buku/mark-closed',
        [LaporanController::class, 'markYearClosed']
    )->name('laporan.tutup_buku.mark_closed');

    Route::post(
        '/laporan/tutup-buku/archive',
        [LaporanController::class, 'archiveJournal']
    )->name('laporan.tutup_buku.archive');

    Route::post(
        '/laporan/tutup-buku/close-year',
        [LaporanController::class, 'closeYear']
    )->name('laporan.tutup_buku.close_year');

    Route::post(
        '/laporan/tutup-buku/remove-closing-journal',
        [LaporanController::class, 'removeClosingJournal']
    )->name('laporan.tutup_buku.remove_closing_journal');

    Route::post(
        '/laporan/tutup-buku/reset-year-close',
        [LaporanController::class, 'resetYearClose']
    )->name('laporan.tutup_buku.reset_year_close');

    Route::get(
        '/laporan/laba-rugi',
        [LaporanController::class, 'labaRugi']
    )->name('laporan.laba_rugi');

    Route::get(
        '/laporan/laba-rugi/excel',
        [LaporanController::class, 'exportLabaRugi']
    )->name('laporan.laba_rugi.excel');

    Route::get('/laporan/{report}/pdf', [LaporanController::class, 'streamReportPdf'])
        ->whereIn('report', ['jurnal-umum', 'coa', 'neraca-saldo', 'arus-kas', 'tutup-buku', 'perubahan-ekuitas', 'laba-rugi'])
        ->name('laporan.stream_pdf');
});

Route::middleware('auth')->group(function () {

    Route::view('/ubah-password', 'profile.password')->name('profile.password');
    Route::patch('/profil/email', [ProfileController::class, 'updateEmail'])->name('profile.email.update');

    Route::get(
        '/profile',
        [ProfileController::class, 'edit']
    )->name('profile.edit');

    Route::patch(
        '/profile',
        [ProfileController::class, 'update']
    )->name('profile.update');

    Route::delete(
        '/profile',
        [ProfileController::class, 'destroy']
    )->name('profile.destroy');
});

require __DIR__ . '/auth.php';
