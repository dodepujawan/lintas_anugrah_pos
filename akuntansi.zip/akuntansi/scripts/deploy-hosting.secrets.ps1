# Rahasia lokal untuk deploy-hosting — JANGAN di-commit / di-upload.
# Dipakai otomatis oleh deploy-hosting.ps1

$DeploySshHost = '202.10.40.136'
$DeploySshUser = 'root'
$DeploySshPassword = 'Lint@s090499'
